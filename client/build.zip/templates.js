export const templates = [
    {
        "id": 1,
        "user_id": 101,
        "name": "Bench Press",
        "muscle_group": "Chest",
        "created_at": "2025-06-01T12:00:00Z",
        "updated_at": "2025-06-10T10:00:00Z"
    },
    {
        "id": 2,
        "user_id": 101,
        "name": "Deadlift",
        "muscle_group": "Back",
        "created_at": "2025-06-05T08:30:00Z",
        "updated_at": "2025-06-15T09:00:00Z"
    },
    {
        "id": 3,
        "user_id": 101,
        "name": "Squat",
        "muscle_group": "Legs",
        "created_at": "2025-06-10T14:00:00Z",
        "updated_at": "2025-06-20T15:00:00Z"
    }
]